// 캐릭터페이지 메인 컨텐츠

import { Banner } from "../modules/Banner";

export function Character() {
    return(
        <>
        {/* 배너 컴포넌트  */}
        <Banner category="CHARACTERS" />
        {/*  */}
        {/*  */}
        </>
    )
} /////////////// 