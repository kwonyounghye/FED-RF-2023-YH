// 비디오페이지 메인 컨텐츠

// import { isrc } from "../data/imgSrc";
import { VidIntro } from "../modules/VidIntro";

export function Video() {
    return(
        <>
        <VidIntro cat="VIDEO" cls="on" />
        </>
    )
} /////////////// Video ////////////////