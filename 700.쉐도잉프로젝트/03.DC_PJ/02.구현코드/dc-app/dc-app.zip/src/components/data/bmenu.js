// 하단 링크 정보
export const bmData = [
    {
        txt: "Privacy Policy",
        link: "https://www.warnermediaprivacy.com/policycenter/b2c/WM/",
    },
    {
        txt: "Terms",
        link: "https://www.dcuniverseinfinite.com/terms?_gl=1*5nxhg2*_gcl_au*MTk3OTgxNzUwMi4xNjgzMTc3NDg3",
    },
    {
        txt: "Ad Choices",
        link: "https://www.warnermediaprivacy.com/policycenter/b2c/wm/",
    },
    {
        txt: "Accessibility",
        link: "https://policies.warnerbros.com/terms/en-us/#accessibility",
    },
    {
        txt: "Cookie Settings",
        link: "https://www.dc.com/#compliance-link",
    },
];